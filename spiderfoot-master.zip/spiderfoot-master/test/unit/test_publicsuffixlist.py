# test_sflib.py
import sflib
import unittest

class TestPublicSuffixList(unittest.TestCase):
    """
    Test PublicSuffixList
    """

    def test_init(self):
        """
        Test __init__(self, input_data)
        """
        self.assertEqual('TBD', 'TBD')

if __name__ == '__main__':
    unittest.main()

