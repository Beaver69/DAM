import os
os.system("clear")
